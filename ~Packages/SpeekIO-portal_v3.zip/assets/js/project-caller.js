$(document).ready(function () {
    dummy(); // remove this
});

function dummy() {
    console.log("Hi! I am dummy! Please remove me.")
}

$(document).ready(function () {
    
    charts();
    chart2();
    chart3();    
    richTextEditor();
   
});
